"use client"

import { useState } from "react"
import Header from "@/components/header"
import Hero from "@/components/hero"
import Features from "@/components/features"
import Dashboard from "@/components/dashboard"
import Technology from "@/components/technology"
import Footer from "@/components/footer"

export default function Home() {
  const [showDashboard, setShowDashboard] = useState(false)

  return (
    <main className="bg-background text-foreground">
      <Header onGetStarted={() => setShowDashboard(!showDashboard)} />
      {!showDashboard ? (
        <>
          <Hero onExplore={() => setShowDashboard(true)} />
          <Features />
          <Technology />
        </>
      ) : (
        <Dashboard />
      )}
      <Footer />
    </main>
  )
}
