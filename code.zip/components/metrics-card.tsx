"use client"

export default function MetricsCard({
  label,
  value,
  unit,
  highlight,
}: {
  label: string
  value: string | number
  unit?: string
  highlight?: boolean
}) {
  return (
    <div
      className={`p-6 rounded-lg border ${highlight ? "bg-accent/10 border-accent/30" : "bg-card/50 border-primary/20"}`}
    >
      <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{label}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-3xl font-bold">{value}</p>
        {unit && <span className="text-muted-foreground text-sm">{unit}</span>}
      </div>
    </div>
  )
}
