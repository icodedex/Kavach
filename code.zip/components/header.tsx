"use client"

export default function Header({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">K</span>
          </div>
          <span className="font-bold text-lg">Kavach 2.0</span>
        </div>
        <nav className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm hover:text-accent transition">
            Features
          </a>
          <a href="#technology" className="text-sm hover:text-accent transition">
            Technology
          </a>
          <a href="#about" className="text-sm hover:text-accent transition">
            About
          </a>
        </nav>
        <button
          onClick={onGetStarted}
          className="px-4 py-2 rounded-full bg-accent text-accent-foreground font-medium text-sm hover:opacity-90 transition"
        >
          Get Started
        </button>
      </div>
    </header>
  )
}
