"use client"

export default function Technology() {
  const techs = [
    {
      category: "Backend",
      items: ["FastAPI", "WebSocket", "MQTT Protocol", "Socket Programming", "SQLite"],
    },
    {
      category: "Hardware/Sensors",
      items: ["LiDAR", "Radar", "Camera Module"],
    },
    {
      category: "AI/ML",
      items: ["Deep Learning Models", "Preprocessing Pipelines", "Real-time Inference"],
    },
  ]

  return (
    <section id="technology" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Technology Stack</h2>
          <p className="text-muted-foreground text-lg">Cutting-edge tools and frameworks powering Kavach 2.0</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {techs.map((tech, i) => (
            <div key={i} className="p-8 rounded-lg border border-primary/20 bg-card/50">
              <h3 className="font-bold text-lg mb-6 text-accent">{tech.category}</h3>
              <ul className="space-y-3">
                {tech.items.map((item, j) => (
                  <li key={j} className="flex items-center gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    <span className="text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
