"use client"

import { useState, useEffect } from "react"
import MetricsCard from "./metrics-card"
import SystemStatus from "./system-status"
import RealTimeChart from "./real-time-chart"

export default function Dashboard() {
  const [metrics, setMetrics] = useState({
    fogDensity: 85,
    visibility: 35,
    detectedObjects: 7,
    responseTime: 42,
    systemHealth: 98,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics((prev) => ({
        fogDensity: Math.max(20, Math.min(100, prev.fogDensity + (Math.random() - 0.5) * 10)),
        visibility: Math.max(10, Math.min(150, prev.visibility + (Math.random() - 0.5) * 8)),
        detectedObjects: Math.floor(Math.random() * 15),
        responseTime: Math.max(30, Math.min(80, prev.responseTime + (Math.random() - 0.5) * 5)),
        systemHealth: Math.max(90, Math.min(100, prev.systemHealth + (Math.random() - 0.5) * 2)),
      }))
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const alerts = [
    { level: "warning", message: "High fog density detected - Caution advised" },
    { level: "info", message: "Radar active - Multiple objects detected" },
    { level: "success", message: "All systems operational" },
  ]

  return (
    <section className="min-h-screen px-6 py-12 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Live Monitoring</h1>
          <p className="text-muted-foreground">Real-time vehicle safety metrics and alerts</p>
        </div>

        {/* Alert banner */}
        <div className="mb-8 p-4 rounded-lg bg-destructive/10 border border-destructive/30">
          <p className="text-sm font-medium text-destructive">
            ⚠️ Fog conditions detected - System in active monitoring mode
          </p>
        </div>

        {/* Metrics grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <MetricsCard label="Fog Density" value={`${Math.round(metrics.fogDensity)}%`} unit="%" />
          <MetricsCard label="Visibility Range" value={`${Math.round(metrics.visibility)}m`} unit="m" />
          <MetricsCard label="Objects Detected" value={metrics.detectedObjects} />
          <MetricsCard label="Response Time" value={`${Math.round(metrics.responseTime)}ms`} unit="ms" />
          <MetricsCard label="System Health" value={`${Math.round(metrics.systemHealth)}%`} highlight />
        </div>

        {/* Charts and system status */}
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RealTimeChart metrics={metrics} />
          </div>
          <SystemStatus alerts={alerts} />
        </div>
      </div>
    </section>
  )
}
