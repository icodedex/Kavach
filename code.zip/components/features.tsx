"use client"

export default function Features() {
  const features = [
    {
      title: "LiDAR Sensing",
      description: "Precise 360° object detection and distance measurement for accurate obstacle identification",
      icon: "📡",
    },
    {
      title: "AI Prediction",
      description: "Machine learning models predict hazards before they become critical incidents",
      icon: "🧠",
    },
    {
      title: "Real-time Alerts",
      description: "Instant WebSocket notifications keep drivers informed of potential dangers",
      icon: "⚡",
    },
    {
      title: "Radar Integration",
      description: "Detect object velocity and trajectory for comprehensive threat assessment",
      icon: "📊",
    },
    {
      title: "Multi-sensor Fusion",
      description: "Combines LiDAR, Radar, and Camera data for robust safety decisions",
      icon: "🔗",
    },
    {
      title: "Low Latency",
      description: "Sub-100ms response time ensures drivers get alerts when they matter most",
      icon: "⚙️",
    },
  ]

  return (
    <section id="features" className="py-20 px-6 bg-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Core Features</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Advanced safety capabilities powered by cutting-edge IoT and AI technology
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="p-6 rounded-lg border border-primary/20 bg-background/50 hover:border-primary/50 transition hover:bg-card/50"
            >
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
