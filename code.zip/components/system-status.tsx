"use client"

export default function SystemStatus({
  alerts,
}: {
  alerts: Array<{ level: string; message: string }>
}) {
  return (
    <div className="p-6 rounded-lg border border-primary/20 bg-card/50">
      <h3 className="font-bold text-lg mb-4">System Status</h3>
      <div className="space-y-3">
        {alerts.map((alert, i) => (
          <div key={i} className="flex gap-3 items-start">
            <div
              className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                alert.level === "warning" ? "bg-yellow-500" : alert.level === "success" ? "bg-green-500" : "bg-blue-500"
              }`}
            />
            <p className="text-sm">{alert.message}</p>
          </div>
        ))}
      </div>

      {/* Quick stats */}
      <div className="mt-6 pt-6 border-t border-border space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Uptime</span>
          <span className="font-semibold">99.8%</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Alerts Today</span>
          <span className="font-semibold">23</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Incidents Prevented</span>
          <span className="font-semibold">3</span>
        </div>
      </div>
    </div>
  )
}
