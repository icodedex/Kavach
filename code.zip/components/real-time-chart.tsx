"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function RealTimeChart({
  metrics,
}: {
  metrics: {
    fogDensity: number
    visibility: number
    responseTime: number
  }
}) {
  // Simulated data for the chart
  const data = [
    { time: "0s", fog: 78, visibility: 40 },
    { time: "5s", fog: 82, visibility: 36 },
    { time: "10s", fog: 85, visibility: 35 },
    { time: "15s", fog: 83, visibility: 37 },
    { time: "20s", fog: Math.round(metrics.fogDensity), visibility: Math.round(metrics.visibility / 4) },
  ]

  return (
    <div className="p-6 rounded-lg border border-primary/20 bg-card/50">
      <h3 className="font-bold text-lg mb-6">Environmental Conditions</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis dataKey="time" stroke="rgba(255,255,255,0.5)" />
          <YAxis stroke="rgba(255,255,255,0.5)" />
          <Tooltip
            contentStyle={{
              backgroundColor: "rgba(20, 20, 30, 0.95)",
              border: "1px solid rgba(100, 150, 255, 0.3)",
              borderRadius: "8px",
            }}
          />
          <Line
            type="monotone"
            dataKey="fog"
            stroke="hsl(262, 100%, 50%)"
            dot={false}
            strokeWidth={2}
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="visibility"
            stroke="hsl(48, 100%, 50%)"
            dot={false}
            strokeWidth={2}
            isAnimationActive={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
