"use client"

export default function Hero({ onExplore }: { onExplore: () => void }) {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 pt-20 pb-10 relative overflow-hidden">
      {/* Background gradient effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-transparent to-transparent -z-10" />

      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-block mb-6 px-4 py-2 rounded-full border border-primary/30 bg-primary/5">
          <span className="text-sm text-accent font-semibold">INTELLIGENT SAFETY SYSTEM</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">
          Fog Detection &<br />
          Collision Prevention
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
          Kavach 2.0 combines AI-powered prediction models with real-time sensor data to detect obstacles and alert
          drivers before collisions occur, keeping you safe in any weather condition.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button
            onClick={onExplore}
            className="px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold hover:opacity-90 transition"
          >
            Explore Dashboard
          </button>
          <button className="px-8 py-3 rounded-full border border-primary/50 hover:border-primary transition font-semibold">
            Learn More
          </button>
        </div>

        {/* Hero visualization */}
        <div className="relative mx-auto max-w-2xl h-80 rounded-xl overflow-hidden border border-primary/30 bg-card/50">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-48 h-48">
              <div className="absolute inset-0 border-2 border-primary rounded-full animate-pulse" />
              <div className="absolute inset-6 border-2 border-accent rounded-full" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-accent rounded-full" />
              <div className="absolute top-1/3 left-1/4 w-3 h-3 bg-destructive rounded-full animate-pulse" />
              <div className="absolute bottom-1/3 right-1/4 w-3 h-3 bg-destructive rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
